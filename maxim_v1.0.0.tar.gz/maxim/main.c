#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>

#include "max11040k.h"

int max11040_handler(uint8_t debugMode, uint8_t en24Bit, uint8_t printRaw, uint8_t printVoltage, int heartz, int sampleRate);

void printHelpAndAbort()
{
	printf("max11040k [-d] [-p] [-r] [-v] [-H reading hertz] [-s <sample rate>]\n");

	printf("\t -h : Prints this help\n");
	printf("\t -d : Enable debug mode\n");
	printf("\t -p : Enable high precision mode (24bit mode)\n");
	printf("\t -r : Prints data in raw mode\n");
	printf("\t -v : Prints data in volts\n");
	printf("\t -H : Heartz to read from the device, should be greater than 0\n");
	printf("\t -s : Set sample rate of the device\n");
	printf("\t\t Possible values are:\n");
	printf("\t\t 1 -  250   samples per second\n");
	printf("\t\t 2 -  250   samples per second\n");
	printf("\t\t 3 -  499   samples per second\n");
	printf("\t\t 4 -  500   samples per second\n");
	printf("\t\t 5 -  500   samples per second\n");
	printf("\t\t 6 -  500   samples per second\n");
	printf("\t\t 7 -  999   samples per second\n");
	printf("\t\t 8 -  1000  samples per second\n");
	printf("\t\t 9 -  1000  samples per second\n");
	printf("\t\t 10 - 1000  samples per second\n");
	printf("\t\t 11 - 1998  samples per second\n");
	printf("\t\t 12 - 2000  samples per second\n");
	printf("\t\t 13 - 2000  samples per second\n");
	printf("\t\t 14 - 2000  samples per second\n");
	printf("\t\t 15 - 3997  samples per second\n");
	printf("\t\t 16 - 4000  samples per second\n");
	printf("\t\t 17 - 4001  samples per second\n");
	printf("\t\t 18 - 4001  samples per second\n");
	printf("\t\t 19 - 7994  samples per second\n");
	printf("\t\t 20 - 8000  samples per second\n");
	printf("\t\t 21 - 8002  samples per second\n");
	printf("\t\t 22 - 8002  samples per second\n");
	printf("\t\t 23 - 15990 samples per second\n");
	printf("\t\t 24 - 16000 samples per second\n");
	printf("\t\t 25 - 16010 samples per second\n");
	printf("\t\t 26 - 16010 samples per second\n");
	printf("\t\t 27 - 31958 samples per second\n");
	printf("\t\t 28 - 32000 samples per second\n");
	printf("\t\t 29 - 32042 samples per second\n");
	printf("\t\t 30 - 32042 samples per second\n");
	printf("\t\t 31 - 63834 samples per second\n");
	printf("\t\t 32 - 64000 samples per second\n");
	printf("\t Example:\n");
	printf("\t Will display most accurate values in voltage twice per second, without debug information\n");
	printf("\t sudo ./max11040k -s 1 -H 2 -v -p\n");
	exit(-1);
}

int main(int argc, char **argv)
{
	
	uint8_t debugMode = 0;
	uint8_t en24Bit = 0;
	uint8_t printRaw = 0;
	uint8_t printVoltage = 0;
	int    sampleRate = -1;
	int    heartz = -1;

	int bflag = 0;
	char *cvalue = NULL;
	int index;
	int c;

	opterr = 0;
	while ((c = getopt (argc, argv, "dprvH:s:")) != -1)
		switch (c)
		{
			case 'd':
				debugMode = 1;
				break;
			case 'p':
				en24Bit = 1;
				break;
			case 'r':
				printRaw = 1;
				break;
			case 'v':
				printVoltage = 1;
				break;
			case 's':
				if ( NULL != optarg )
				{
					sampleRate = strtol( optarg, NULL, 10) - 1;
				}
				if (  sampleRate < e_DataRate_250_v0  ||
						sampleRate > e_DataRate_64000 )
				{
					printf("Wrong sample rate specified\n");
					printHelpAndAbort();
				}
				break;
			case 'H':
				if ( NULL != optarg )
				{
					heartz = strtol( optarg, NULL, 10);
				}
				if ( 0 == heartz )
				{
					printf("Wrong heartz specified\n");
					printHelpAndAbort();
				}
				break;
			case 'h':
				printHelpAndAbort();
			default:
				printHelpAndAbort();
		}
	if ( -1 == sampleRate || -1 == heartz)
       	{
		printf("-s and -H should be set\n");
		printHelpAndAbort();
	}

	return max11040_handler( debugMode, en24Bit, printRaw, printVoltage, heartz, sampleRate);
}

int max11040_handler(uint8_t debugMode, uint8_t en24Bit, uint8_t printRaw, uint8_t printVoltage, int heartz, int sampleRate)
{
	max11040k_debugOn( debugMode);

	if ( 0 != max11040k_init() )
	{
		printf("Unable to initialize max11040k, please try as root\n");
		return -1;
	}

	usleep(100000);
	max11040k_enable24Bit( en24Bit);

	usleep(100000);
	max11040k_setDataRate( (enum dataRates)sampleRate);


	usleep(100000);
	while (1)
	{
		struct dataRegister data = { 0 };  
		max11040k_readDataRegister( &data);

		if ( 1 == printRaw )
		{
			printf("Raw_Channel_0: %.8X\tRaw_Channel_1: %.8X\tRaw_Channel_2: %.8X\tRaw_Channel_3: %.8X\n",
					data.rawChannel0,
					data.rawChannel1,
					data.rawChannel2,
					data.rawChannel3);
		}

		if ( 1 == printVoltage )
		{
			printf("V_Channel_0: %f\tV_Channel_1: %f\tV_Channel_2: %f\tV_Channel_3: %f\n",
					data.vChannel0,
					data.vChannel1,
					data.vChannel2,
					data.vChannel3);
		}
		if ( 1 == heartz )
		{
			sleep(1);
		}
		else
		{
			usleep(1000000 / heartz);
		}
	}
	return 0;
}
