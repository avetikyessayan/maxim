// spi.c
//
// Example program for bcm2835 library
// Shows how to interface with SPI to transfer a byte to and from an SPI device
//
// After installing bcm2835, you can build this 
// with something like:
// gcc -o spi spi.c -l bcm2835
// sudo ./spi
//
// Or you can test it before installing with:
// gcc -o spi -I ../../src ../../src/bcm2835.c spi.c
// sudo ./spi
//
// Author: Mike McCauley
// Copyright (C) 2012 Mike McCauley
// $Id: RF22.h,v 1.21 2012/05/30 01:51:25 mikem Exp $
#include <bcm2835.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>

//#define RAW_INTEGER
#define DATA_24_BIT

int main(int argc, char **argv)
{
    // If you call this, it will not actually access the GPIO
// Use for testing
//        bcm2835_set_debug(1);
    if (!bcm2835_init())
    {
      printf("bcm2835_init failed. Are you running as root??\n");
      return 1;
    }
    if (!bcm2835_spi_begin())
    {
      printf("bcm2835_spi_begin failed. Are you running as root??\n");
      return 1;
    }
    bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);      // The default
    bcm2835_spi_setDataMode(BCM2835_SPI_MODE2);                   // The default
    bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_65536); // The default
    bcm2835_spi_chipSelect(BCM2835_SPI_CS0);                      // The default
    // bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, HIGH);     
    bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);     

    {
	    uint8_t writeConfigurationRegister = 0b01100000;
#ifdef  DATA_24_BIT
	    uint8_t write_config[2] = { writeConfigurationRegister, 0b00110000};
#else
	    uint8_t write_config[2] = { writeConfigurationRegister, 0b00010000};
#endif

	    printf("Write Configuration Register\n");
	    bcm2835_spi_writenb ( write_config, sizeof(write_config));
	    for ( int i = 0;  i < sizeof(write_config); ++i)
	    {
		    printf("Sent to SPI: 0x%02X\n", write_config[i]);
	    }
    }

    printf("\n");
    uint8_t readSamplingInstantControlRegister = 0b11000000;
    uint8_t send_data[5] = { readSamplingInstantControlRegister };
    uint8_t read_data[5] = { 0 };

    printf("Read Sampling Instanct Control Register\n");
    bcm2835_spi_transfernb ( send_data, read_data, sizeof(send_data));
    for ( int i = 0;  i < sizeof(send_data); ++i)
    {
	    printf("Sent to SPI: 0x%02X. Read back from SPI: 0x%02X.\n", send_data[i], read_data[i]);
    }
    printf("\n");

    uint8_t writeDataRateControlRegister = 0b01010000;
    uint8_t writeDataRate[3] = { writeDataRateControlRegister, 0b00100110, 0b00000000 };

    printf("Write Data Rate Control Register\n");
    bcm2835_spi_writenb ( writeDataRate, sizeof(writeDataRate));

    for ( int i = 0;  i < sizeof(writeDataRate); ++i)
    {
	    printf("Sent to SPI: 0x%02X.\n", writeDataRate[i]);
    }
    printf("\n");

    uint8_t readDataRateControlRegister = 0b11010000;
    uint8_t send_data1[3] = { readDataRateControlRegister };
    uint8_t read_data1[3] = { 0 };

    printf("Read Data Rate Control Register\n");
    bcm2835_spi_transfernb ( send_data1, read_data1, sizeof(send_data1));
    for ( int i = 0;  i < sizeof(send_data1); ++i)
    {
	    printf("Sent to SPI: 0x%02X. Read back from SPI: 0x%02X.\n", send_data1[i], read_data1[i]);
    }
    printf("\n");

    uint8_t readConfigurationRegister = 0b11100000;
    uint8_t send_data2[2] = { readConfigurationRegister};
    uint8_t read_data2[2] = { 0 };

    printf("Read Configuration Register\n");
    bcm2835_spi_transfernb ( send_data2, read_data2, sizeof(send_data2));
    for ( int i = 0;  i < sizeof(send_data2); ++i)
    {
	    printf("Sent to SPI: 0x%02X. Read back from SPI: 0x%02X.\n", send_data2[i], read_data2[i]);
    }
    printf("\n");

    uint8_t readDataRegister = 0b11110000;
    uint8_t send_data3[13] = { readDataRegister };
    uint8_t read_data3[13] = { 0 };

    printf("Read Data Register\n");

#ifdef DATA_24_BIT
    double delta_step = 2.2 / (pow(2, 23) - 1);
#else
    double delta_step = 2.2 / (pow(2, 18) - 1);
#endif
    while (1)
    { 
	    bcm2835_spi_transfernb ( send_data3, read_data3, sizeof(send_data3));
	    int32_t raw_channel1; 
	    int32_t raw_channel2;
	    int32_t raw_channel3;
	    int32_t raw_channel4; 

#ifdef DATA_24_BIT
	    raw_channel1 = (int32_t)(read_data3[1] << 24 | read_data3[2] << 16 | read_data3[3] << 8) >> 8;
	    raw_channel2 = (int32_t)(read_data3[4] << 24 | read_data3[5] << 16 | read_data3[6] << 8) >> 8;
	    raw_channel3 = (int32_t)(read_data3[7] << 24 | read_data3[8] << 16 | read_data3[9] << 8) >> 8;
	    raw_channel4 = (int32_t)(read_data3[10] << 24 | read_data3[11] << 16 | read_data3[12] << 8) >> 8;
#else
	    raw_channel1 = (int32_t)(read_data3[1] << 24 | read_data3[2] << 16 | read_data3[3] << 8) >> 13;
	    raw_channel2 = (int32_t)(read_data3[4] << 24 | read_data3[5] << 16 | read_data3[6] << 8) >> 13;
	    raw_channel3 = (int32_t)(read_data3[7] << 24 | read_data3[8] << 16 | read_data3[9] << 8) >> 13;
	    raw_channel4 = (int32_t)(read_data3[10] << 24 | read_data3[11] << 16 | read_data3[12] << 8) >> 13;

	    if ( (0 != (read_data3[3] & 0b11)) ||
			    (1 != (read_data3[6] & 0b11)) ||
			    (2 != (read_data3[9] & 0b11)) ||
			    (3 != (read_data3[12] & 0b11)) ) {
		    printf("Error in channel tags\n");
		    printf("%d\n", read_data3[3] );
		    printf("%d\n", read_data3[6] );
		    printf("%d\n", read_data3[9] );
		    printf("%d\n", read_data3[12] );
	    }


#endif

#ifdef RAW_INTEGER
	    printf("Raw_Channel_0: %.8X\tRaw_Channel_1: %.8X\tRaw_Channel_2: %.8X\tRaw_Channel_3: %.8X\n",
			    raw_channel1,
			    raw_channel2,
			    raw_channel3,
			    raw_channel4);
#else

	    double voltage_channel1 = raw_channel1 * delta_step; 
	    double voltage_channel2 = raw_channel2 * delta_step; 
	    double voltage_channel3 = raw_channel3 * delta_step; 
	    double voltage_channel4 = raw_channel4 * delta_step; 
	    printf("V_Channel_0: %f\tV_Channel_1: %f\tV_Channel_2: %f\tV_Channel_3: %f\n",
			    voltage_channel1,
			    voltage_channel2,
			    voltage_channel3,
			    voltage_channel4);


#endif
	    usleep(100000);
    }
    bcm2835_spi_end();
    bcm2835_close();
    return 0;
}
