#include "max11040k.h"

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <bcm2835.h>

static uint8_t sDebugOn = 0;
static uint8_t sEn24Bit = 0;
static double  sDeltaStep = 0;

static int max11040k_readSamplingInstantControlRegister(struct samplingInstantControlRegister *);
static int max11040k_writeSamplingInstantControlRegister(struct samplingInstantControlRegister *);
static int max11040k_readDataRateControlRegister(struct dataRateControlRegister *);
static int max11040k_writeDataRateControlRegister(struct dataRateControlRegister *);
static int max11040k_writeConfiguration(struct configurationRegister *);
static int max11040k_readConfiguration(struct configurationRegister *);

int max11040k_setDataRate(enum dataRates rate)
{
	if( 1 == sDebugOn )
	{
		printf("Setting data rate to %u\n", rate);
	}

	struct dataRateControlRegister dataRate;
	dataRate.reserved = 0;

	switch ( rate ) {
		case e_DataRate_250_v0:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_250_v1:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_499:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_500_v0:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_500_v1:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_500_v2:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_999:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_1000_v0:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_1000_v1:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_1000_v2:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_1998:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_2000_v0:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_2000_v1:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_2000_v2:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_3997:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_4000:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_4001_v0:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_4001_v1:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_7994:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_8000:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_8002_v0:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_8002_v1:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_15990:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_16000:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_16010_v0:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_16010_v1:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_31958:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b00000000010;
			break;
		case e_DataRate_32000:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_32042_v0:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_32042_v1:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_63834:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b00000000100;
			break;
		case e_DataRate_64000:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b00000000000;
			break;
		default:
			return -1;
			
	}


	return max11040k_writeDataRateControlRegister( &dataRate);
}

int max11040k_enable24Bit(uint8_t enable)
{
	int retVal = -1;

	if( 1 == sDebugOn )
	{
		printf("Setting 24 bit mode to %u\n", enable);
	}

	struct configurationRegister cnf;
	if ( 0 == max11040k_readConfiguration( &cnf) )
	{
		cnf.EN24BIT = enable;
		if ( 0 == max11040k_writeConfiguration(&cnf))
		{
			if ( 1 == enable ) 
			{
				sDeltaStep = 2.2 / (pow(2, 23) - 1);
			}
			else
		       	{
				sDeltaStep = 2.2 / (pow(2, 18) - 1);
			}
			sEn24Bit = enable; 
			retVal = 0;

		}
	}

	return retVal;
}

int max11040k_debugOn(uint8_t on)
{
	sDebugOn = on;
}

int max11040k_init()
{

    if (!bcm2835_init())
    {
      return -1;
    }
    if (!bcm2835_spi_begin())
    {
      return -1;
    }
    bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);
    bcm2835_spi_setDataMode(BCM2835_SPI_MODE2);    
    bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_65536);
    bcm2835_spi_chipSelect(BCM2835_SPI_CS0);               
    bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);     

    struct configurationRegister cnfReg;
    cnfReg.SHDN = 0;
    cnfReg.RST = 0;
    cnfReg.EN24BIT = 1;
    cnfReg.XTALEN = 1;
    cnfReg.FAULTDIS = 0;
    cnfReg.PDBUF = 0;
    cnfReg.reserved = 0;

    sEn24Bit = 1;
    sDeltaStep = 2.2 / (pow(2, 23) - 1);
    return max11040k_writeConfiguration(&cnfReg);
}

static int max11040k_readSamplingInstantControlRegister(struct samplingInstantControlRegister * sInst)
{
	// Not implemented
	return -1;
}

static int max11040k_writeSamplingInstantControlRegister(struct samplingInstantControlRegister * sInst)
{
	// Not implemented
	return -1;
}

static int max11040k_readDataRateControlRegister(struct dataRateControlRegister * dataRate)
{
    uint8_t opCode = 0b11010000;
    uint8_t readDataRateTx[3] = { 0 };
    uint8_t readDataRateRx[3] = { 0 };

    readDataRateTx[0] = opCode;

    bcm2835_spi_transfernb ( readDataRateTx, readDataRateRx, sizeof(readDataRateTx));
	
    if( 1 == sDebugOn )
    {
	    printf("Read Data Rate Control Register\n");
	    for ( int i = 0;  i < sizeof(readDataRateTx); ++i)
	    {
		    printf("Sent to SPI: 0x%02X. Read back from SPI: 0x%02X.\n",readDataRateTx[i], readDataRateRx[i]);
	    }
	    printf("\n");
    }

    dataRate->FSAMPC = (readDataRateRx[1] & 0b11100000) >> 5;	
    dataRate->reserved = 0;
    dataRate->FSAMPF = ((readDataRateRx[1] & 0b00000111) << 8) | readDataRateRx[2];	
    return 0;

}

static int max11040k_writeDataRateControlRegister(struct dataRateControlRegister * dataRate)
{
	int retVal = -1;

	uint8_t opCode = 0b01010000;
	uint8_t writeDataRate[3] = { 0 };

	writeDataRate[0] = opCode;
	writeDataRate[1] = (dataRate->FSAMPC << 5) | (dataRate->FSAMPF >> 8);
	writeDataRate[2] = dataRate->FSAMPF & 0xFF;

	bcm2835_spi_writenb ( writeDataRate, sizeof(writeDataRate));

	if( 1 == sDebugOn )
	{
		printf("Write Data Rate Control Register\n");
		for ( int i = 0;  i < sizeof(writeDataRate); ++i)
		{
			printf("Sent to SPI: 0x%02X.\n", writeDataRate[i]);
		}
		printf("\n");
	}

	dataRate->reserved = 0;
	struct dataRateControlRegister dataRateCheck;
	if ( 0 == max11040k_readDataRateControlRegister(&dataRateCheck))
	{

		if ( 0 != memcmp( dataRate, &dataRateCheck, sizeof(dataRateCheck)))
		{
			if( 1 == sDebugOn )
			{
				printf("Write data rate failed\n");
				printf("Wrote FSAMPC: %u, R: %u, FSAMPF: %u\n", dataRate->FSAMPC, dataRate->reserved, dataRate->FSAMPF);
				printf("Read  FSAMPC: %u, R: %u, FSAMPF: %u\n", dataRateCheck.FSAMPC, dataRateCheck.reserved, dataRateCheck.FSAMPF);
			}
		}
		else 
		{
			retVal = 0;
		}
	}

	return retVal;
}

static int max11040k_readConfiguration(struct configurationRegister * cnf)
{
	uint8_t opCode = 0b11100000;
	uint8_t readConfigTx[2] = { 0 };
	uint8_t readConfigRx[2] = { 0 };

	readConfigTx[0] = opCode;

	bcm2835_spi_transfernb ( readConfigTx, readConfigRx, sizeof(readConfigTx));

	if( 1 == sDebugOn )
	{
		printf("Read Configuration Register\n");
		for ( int i = 0;  i < sizeof(readConfigTx); ++i)
		{
			printf("Sent to SPI: 0x%02X. Read back from SPI: 0x%02X.\n",readConfigTx[i],readConfigRx[i]);
		}
		printf("\n");
	}

	cnf->SHDN     = (readConfigRx[1] & (1 << 7)) > 0 ? 1 : 0;
	cnf->RST      = (readConfigRx[1] & (1 << 6)) > 0 ? 1 : 0;
	cnf->EN24BIT  = (readConfigRx[1] & (1 << 5)) > 0 ? 1 : 0;
	cnf->XTALEN   = (readConfigRx[1] & (1 << 4)) > 0 ? 1 : 0;
	cnf->FAULTDIS = (readConfigRx[1] & (1 << 3)) > 0 ? 1 : 0;
	cnf->PDBUF    = (readConfigRx[1] & (1 << 2)) > 0 ? 1 : 0;
	cnf->reserved = 0;

	return 0;
}

static int max11040k_writeConfiguration(struct configurationRegister * cnf)
{
	int retVal = -1;
	uint8_t opCode = 0b01100000;
	uint8_t cnfByte = cnf->SHDN << 7       |
		cnf->RST << 6      |
		cnf->EN24BIT << 5  |
		cnf->XTALEN << 4   |
		cnf->FAULTDIS << 3 |
		cnf->PDBUF << 2;

	uint8_t writeConfig[2];
	writeConfig[0] = opCode;
	writeConfig[1] = cnfByte;

	bcm2835_spi_writenb (writeConfig, sizeof(writeConfig));

	if( 1 == sDebugOn )
	{
		printf("Writing Configuration Register\n");
		for ( int i = 0;  i < sizeof(writeConfig); ++i)
		{
			printf("Sent to SPI: 0x%02X\n", writeConfig[i]);
		}
	}

	cnf->reserved = 0;
	struct configurationRegister cnfCheck;
	if ( 0 == max11040k_readConfiguration(&cnfCheck))
	{
		if ( 0 != memcmp( cnf, &cnfCheck, sizeof(cnfCheck)))
		{
			if( 1 == sDebugOn )
			{
				printf("Write configuration failed\n");
			}
		}
		else
		{
			retVal = 0;
		}
	}

	return retVal;
}

int max11040k_readDataRegister(struct dataRegister * data)
{

	uint8_t opCode = 0b11110000;
	uint8_t readDataRegisterTx[13] = { 0 };
	uint8_t readDataRegisterRx[13] = { 0 };

	readDataRegisterTx[0] = opCode;

	if ( 1 == sDebugOn ) {
		printf("Reading Data Register\n");
	}
	bcm2835_spi_transfernb ( readDataRegisterTx, readDataRegisterRx, sizeof(readDataRegisterTx));

	if ( 1 == sEn24Bit ) 
	{
		data->rawChannel0 = (int32_t)(readDataRegisterRx[1] << 24 | readDataRegisterRx[2] << 16 | readDataRegisterRx[3] << 8) >> 8;
		data->rawChannel1 = (int32_t)(readDataRegisterRx[4] << 24 | readDataRegisterRx[5] << 16 | readDataRegisterRx[6] << 8) >> 8;
		data->rawChannel2 = (int32_t)(readDataRegisterRx[7] << 24 | readDataRegisterRx[8] << 16 | readDataRegisterRx[9] << 8) >> 8;
		data->rawChannel3 = (int32_t)(readDataRegisterRx[10] << 24 | readDataRegisterRx[11] << 16 | readDataRegisterRx[12] << 8) >> 8;
	}
	else {

		data->rawChannel0 = (int32_t)(readDataRegisterRx[1] << 24 | readDataRegisterRx[2] << 16 | readDataRegisterRx[3] << 8) >> 13;
		data->rawChannel1 = (int32_t)(readDataRegisterRx[4] << 24 | readDataRegisterRx[5] << 16 | readDataRegisterRx[6] << 8) >> 13;
		data->rawChannel2 = (int32_t)(readDataRegisterRx[7] << 24 | readDataRegisterRx[8] << 16 | readDataRegisterRx[9] << 8) >> 13;
		data->rawChannel3 = (int32_t)(readDataRegisterRx[10] << 24 | readDataRegisterRx[11] << 16 | readDataRegisterRx[12] << 8) >> 13;

		if ( (0 != (readDataRegisterRx[3] & 0b11)) ||
				(1 != (readDataRegisterRx[6] & 0b11)) ||
				(2 != (readDataRegisterRx[9] & 0b11)) ||
				(3 != (readDataRegisterRx[12] & 0b11)) ) {
			if ( 1 == sDebugOn ) {
				printf("Error while reading data register, tag mismatch\n");
				printf("%d\n", readDataRegisterRx[3] );
				printf("%d\n", readDataRegisterRx[6] );
				printf("%d\n", readDataRegisterRx[9] );
				printf("%d\n", readDataRegisterRx[12] );
			}
			return -1;
		}

	}

	data->vChannel0 = data->rawChannel0 * sDeltaStep; 
	data->vChannel1 = data->rawChannel1 * sDeltaStep; 
	data->vChannel2 = data->rawChannel2 * sDeltaStep; 
	data->vChannel3 = data->rawChannel3 * sDeltaStep; 
	return 0;
}
