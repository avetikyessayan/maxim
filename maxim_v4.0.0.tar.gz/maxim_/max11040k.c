#include "max11040k.h"

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <bcm2835.h>

static uint8_t sDebugOn = 0;
static uint8_t sEn24Bit = 0;
static double  sDeltaStep = 0;
static double  sNumberOfDevices = 0;

static int max11040k_readSamplingInstantControlRegister(struct samplingInstantControlRegister *, uint8_t numberOfDevices);
static int max11040k_writeSamplingInstantControlRegister(struct samplingInstantControlRegister *, uint8_t numberOfDevices);
static int max11040k_readDataRateControlRegister(struct dataRateControlRegister *);
static int max11040k_writeDataRateControlRegister(struct dataRateControlRegister *);
static int max11040k_writeConfiguration(struct configurationRegister *, uint8_t numberOfDevices);
static int max11040k_readConfiguration(struct configurationRegister *, uint8_t numberOfDevices);

int max11040k_setDataRate(enum dataRates rate)
{
	if( 1 == sDebugOn )
	{
		printf("Setting data rate to %u\n", rate);
	}

	struct dataRateControlRegister dataRate;
	dataRate.reserved = 0;

	switch ( rate ) {
		case e_DataRate_250_v0:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_250_v1:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_499:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_500_v0:
			dataRate.FSAMPC = 0b001;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_500_v1:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_500_v2:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_999:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_1000_v0:
			dataRate.FSAMPC = 0b010;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_1000_v1:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_1000_v2:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_1998:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_2000_v0:
			dataRate.FSAMPC = 0b011;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_2000_v1:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_2000_v2:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_3997:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_4000:
			dataRate.FSAMPC = 0b100;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_4001_v0:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_4001_v1:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_7994:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_8000:
			dataRate.FSAMPC = 0b101;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_8002_v0:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_8002_v1:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_15990:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b00000000001;
			break;
		case e_DataRate_16000:
			dataRate.FSAMPC = 0b000;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_16010_v0:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_16010_v1:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_31958:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b00000000010;
			break;
		case e_DataRate_32000:
			dataRate.FSAMPC = 0b110;
			dataRate.FSAMPF = 0b00000000000;
			break;
		case e_DataRate_32042_v0:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b11000000000;
			break;
		case e_DataRate_32042_v1:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b10111111111;
			break;
		case e_DataRate_63834:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b00000000100;
			break;
		case e_DataRate_64000:
			dataRate.FSAMPC = 0b111;
			dataRate.FSAMPF = 0b00000000000;
			break;
		default:
			return -1;
			
	}


	return max11040k_writeDataRateControlRegister( &dataRate);
}

int max11040k_enable24Bit(uint8_t enable)
{
	int retVal = -1;

	if( 1 == sDebugOn )
	{
		printf("Setting 24 bit mode to %u\n", enable);
	}

	struct configurationRegister cnf[MAX11040_MAX_SUPPORTED_DEVICE_COUNT];
	if ( 0 == max11040k_readConfiguration( cnf, sNumberOfDevices) )
	{
		for ( int i = 0; i < MAX11040_MAX_SUPPORTED_DEVICE_COUNT; ++i ) {
			cnf[i].EN24BIT = enable;
		}
		if ( 0 == max11040k_writeConfiguration(cnf, sNumberOfDevices))
		{
			if ( 1 == enable ) 
			{
				sDeltaStep = 2.2 / (pow(2, 23) - 1);
			}
			else
		       	{
				sDeltaStep = 2.2 / (pow(2, 18) - 1);
			}
			sEn24Bit = enable; 
			retVal = 0;

		}
	}

	return retVal;
}

int max11040k_debugOn(uint8_t on)
{
	sDebugOn = on;
}

int max11040k_init(uint8_t numberOfDevices)
{

    if (!bcm2835_init())
    {
      return -1;
    }
    if (!bcm2835_spi_begin())
    {
      return -1;
    }
    bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);
    bcm2835_spi_setDataMode(BCM2835_SPI_MODE2);    
    bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_65536);
    bcm2835_spi_chipSelect(BCM2835_SPI_CS0);               
    bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);     

    struct configurationRegister cnfReg[MAX11040_MAX_SUPPORTED_DEVICE_COUNT];
    for ( int i = 0; i < numberOfDevices; ++i ) {
	    cnfReg[i].SHDN = 0;
	    cnfReg[i].RST = 0;
	    cnfReg[i].EN24BIT = 1;
	    cnfReg[i].XTALEN = 0;
	    if ( 0 == i ) 
		    cnfReg[i].XTALEN = 1;
	    cnfReg[i].FAULTDIS = 0;
	    cnfReg[i].PDBUF = 0;
	    cnfReg[i].reserved = 0;
    }

    sNumberOfDevices = numberOfDevices;
    sEn24Bit = 1;
    sDeltaStep = 2.2 / (pow(2, 23) - 1);
    return max11040k_writeConfiguration(cnfReg, sNumberOfDevices);
}

static int max11040k_readSamplingInstantControlRegister(struct samplingInstantControlRegister * sInst, uint8_t numberOfDevices)
{
	// Not implemented
	return -1;
}

static int max11040k_writeSamplingInstantControlRegister(struct samplingInstantControlRegister * sInst, uint8_t numberOfDevices)
{
	// Not implemented
	return -1;
}

static int max11040k_readDataRateControlRegister(struct dataRateControlRegister * dataRate)
{
    uint8_t opCode = 0b11010000;
    uint8_t readDataRateTx[3] = { 0 };
    uint8_t readDataRateRx[3] = { 0 };

    readDataRateTx[0] = opCode;

    bcm2835_spi_transfernb ( readDataRateTx, readDataRateRx, sizeof(readDataRateTx));
	
    if( 1 == sDebugOn )
    {
	    printf("Read Data Rate Control Register\n");
	    for ( int i = 0;  i < sizeof(readDataRateTx); ++i)
	    {
		    printf("Sent to SPI: 0x%02X. Read back from SPI: 0x%02X.\n",readDataRateTx[i], readDataRateRx[i]);
	    }
	    printf("\n");
    }

    dataRate->FSAMPC = (readDataRateRx[1] & 0b11100000) >> 5;	
    dataRate->reserved = 0;
    dataRate->FSAMPF = ((readDataRateRx[1] & 0b00000111) << 8) | readDataRateRx[2];	
    return 0;

}

static int max11040k_writeDataRateControlRegister(struct dataRateControlRegister * dataRate)
{
	int retVal = -1;

	uint8_t opCode = 0b01010000;
	uint8_t writeDataRate[3] = { 0 };

	writeDataRate[0] = opCode;
	writeDataRate[1] = (dataRate->FSAMPC << 5) | (dataRate->FSAMPF >> 8);
	writeDataRate[2] = dataRate->FSAMPF & 0xFF;

	bcm2835_spi_writenb ( writeDataRate, sizeof(writeDataRate));

	if( 1 == sDebugOn )
	{
		printf("Write Data Rate Control Register\n");
		for ( int i = 0;  i < sizeof(writeDataRate); ++i)
		{
			printf("Sent to SPI: 0x%02X.\n", writeDataRate[i]);
		}
		printf("\n");
	}

	dataRate->reserved = 0;
	struct dataRateControlRegister dataRateCheck;
	if ( 0 == max11040k_readDataRateControlRegister(&dataRateCheck))
	{

		if ( 0 != memcmp( dataRate, &dataRateCheck, sizeof(dataRateCheck)))
		{
			if( 1 == sDebugOn )
			{
				printf("Write data rate failed\n");
				printf("Wrote FSAMPC: %u, R: %u, FSAMPF: %u\n", dataRate->FSAMPC, dataRate->reserved, dataRate->FSAMPF);
				printf("Read  FSAMPC: %u, R: %u, FSAMPF: %u\n", dataRateCheck.FSAMPC, dataRateCheck.reserved, dataRateCheck.FSAMPF);
			}
		}
		else 
		{
			retVal = 0;
		}
	}

	return retVal;
}

static int max11040k_readConfiguration(struct configurationRegister * cnf, uint8_t numberOfDevices)
{
	uint8_t opCode = 0b11100000;
	uint8_t readConfigTx[MAX11040_MAX_SUPPORTED_DEVICE_COUNT * 1 + 1] = { 0 };
	uint8_t readConfigRx[MAX11040_MAX_SUPPORTED_DEVICE_COUNT * 1 + 1] = { 0 };

	readConfigTx[0] = opCode;

	bcm2835_spi_transfernb ( readConfigTx, readConfigRx, (1 * numberOfDevices) + 1);

	if( 1 == sDebugOn )
	{
		printf("Read Configuration Register\n");
		for ( int i = 0;  i < ((1 * numberOfDevices) + 1); ++i)
		{
			printf("Sent to SPI: 0x%02X. Read back from SPI: 0x%02X.\n",readConfigTx[i],readConfigRx[i]);
		}
		printf("\n");
	}
	for ( int i = 0; i < numberOfDevices; ++i ) {
		uint8_t offset = i * 1;

		cnf[i].SHDN     = (readConfigRx[offset + 1] & (1 << 7)) > 0 ? 1 : 0;
		cnf[i].RST      = (readConfigRx[offset + 1] & (1 << 6)) > 0 ? 1 : 0;
		cnf[i].EN24BIT  = (readConfigRx[offset + 1] & (1 << 5)) > 0 ? 1 : 0;
		cnf[i].XTALEN   = (readConfigRx[offset + 1] & (1 << 4)) > 0 ? 1 : 0;
		cnf[i].FAULTDIS = (readConfigRx[offset + 1] & (1 << 3)) > 0 ? 1 : 0;
		cnf[i].PDBUF    = (readConfigRx[offset + 1] & (1 << 2)) > 0 ? 1 : 0;
		cnf[i].reserved = 0;
	}

	return 0;
}

static int max11040k_writeConfiguration(struct configurationRegister * cnf, uint8_t numberOfDevices)
{
	int retVal = -1;
	uint8_t opCode = 0b01100000;
	uint8_t writeConfig[MAX11040_MAX_SUPPORTED_DEVICE_COUNT * 1 + 1];
	writeConfig[0] = opCode;

	for ( int i = 0; i < numberOfDevices; ++i ) {
		uint8_t cnfByte = cnf[i].SHDN << 7       |
			cnf[i].RST << 6      |
			cnf[i].EN24BIT << 5  |
			cnf[i].XTALEN << 4   |
			cnf[i].FAULTDIS << 3 |
			cnf[i].PDBUF << 2;
		writeConfig[i + 1] = cnfByte;
		cnf[i].reserved = 0;
	}
	bcm2835_spi_writenb (writeConfig, (1 * numberOfDevices) + 1);

	if( 1 == sDebugOn )
	{
		printf("Writing Configuration Register\n");
		for ( int i = 0;  i < ((1 * numberOfDevices) + 1); ++i)
		{
			printf("Sent to SPI: 0x%02X\n", writeConfig[i]);
		}
	}

	struct configurationRegister cnfCheck[MAX11040_MAX_SUPPORTED_DEVICE_COUNT];
	if ( 0 == max11040k_readConfiguration(cnfCheck, numberOfDevices))
	{
		if ( 0 != memcmp( cnf, cnfCheck, sizeof(struct configurationRegister) * numberOfDevices))
		{
			if( 1 == sDebugOn )
			{
				printf("Write configuration failed\n");
			}
		}
		else
		{
			retVal = 0;
		}
	}

	return retVal;
}

int max11040k_readDataRegister(struct dataRegister *data, uint8_t numberOfDevices)
{

	uint8_t opCode = 0b11110000;
	uint8_t readDataRegisterTx[12 * MAX11040_MAX_SUPPORTED_DEVICE_COUNT + 1] = { 0 };
	uint8_t readDataRegisterRx[12 * MAX11040_MAX_SUPPORTED_DEVICE_COUNT + 1] = { 0 };

	readDataRegisterTx[0] = opCode;

	if ( 1 == sDebugOn ) {
		printf("Reading Data Register, number of devices %d\n", numberOfDevices);
	}

	bcm2835_spi_transfernb ( readDataRegisterTx, readDataRegisterRx, (12 * numberOfDevices) + 1);

	for ( int i = 0; i < numberOfDevices; ++i ) {
		uint8_t offset = i * 12;
		if ( 1 == sEn24Bit ) 
		{
			data[i].rawChannel0 = (int32_t)(readDataRegisterRx[offset + 1] << 24 | readDataRegisterRx[offset + 2] << 16 | readDataRegisterRx[offset + 3] << 8) >> 8;
			data[i].rawChannel1 = (int32_t)(readDataRegisterRx[offset + 4] << 24 | readDataRegisterRx[offset + 5] << 16 | readDataRegisterRx[offset + 6] << 8) >> 8;
			data[i].rawChannel2 = (int32_t)(readDataRegisterRx[offset + 7] << 24 | readDataRegisterRx[offset + 8] << 16 | readDataRegisterRx[offset + 9] << 8) >> 8;
			data[i].rawChannel3 = (int32_t)(readDataRegisterRx[offset + 10] << 24 | readDataRegisterRx[offset + 11] << 16 | readDataRegisterRx[offset + 12] << 8) >> 8;
		}
		else {

			data[i].rawChannel0 = (int32_t)(readDataRegisterRx[offset + 1] << 24 | readDataRegisterRx[offset + 2] << 16 | readDataRegisterRx[offset + 3] << 8) >> 13;
			data[i].rawChannel1 = (int32_t)(readDataRegisterRx[offset + 4] << 24 | readDataRegisterRx[offset + 5] << 16 | readDataRegisterRx[offset + 6] << 8) >> 13;
			data[i].rawChannel2 = (int32_t)(readDataRegisterRx[offset + 7] << 24 | readDataRegisterRx[offset + 8] << 16 | readDataRegisterRx[offset + 9] << 8) >> 13;
			data[i].rawChannel3 = (int32_t)(readDataRegisterRx[offset + 10] << 24 | readDataRegisterRx[offset + 11] << 16 | readDataRegisterRx[offset + 12] << 8) >> 13;

			// Check for the channel address tag
			if ( (i != (readDataRegisterRx[offset + 3] & 0b11100) >> 2) ||
					(i != ((readDataRegisterRx[offset + 6] & 0b11100) >> 2)) ||
					(i != ((readDataRegisterRx[offset + 9] & 0b11100) >> 2)) ||
					(i != ((readDataRegisterRx[offset + 12] & 0b11100) >> 2)) ) {
				if ( 1 == sDebugOn ) {
					printf("Error while reading data register, device address tag mismatch, device: %d\n", i);
					printf("%d\n", readDataRegisterRx[offset + 3] );
					printf("%d\n", readDataRegisterRx[offset + 6] );
					printf("%d\n", readDataRegisterRx[offset + 9] );
					printf("%d\n", readDataRegisterRx[offset + 12] );
				}
				return -1;
			}

			// Check for the channel address tag
			if ( (0 != (readDataRegisterRx[offset + 3] & 0b11)) ||
					(1 != (readDataRegisterRx[offset + 6] & 0b11)) ||
					(2 != (readDataRegisterRx[offset + 9] & 0b11)) ||
					(3 != (readDataRegisterRx[offset + 12] & 0b11)) ) {
				if ( 1 == sDebugOn ) {
					printf("Error while reading data register, channel address tag mismatch\n");
					printf("%d\n", readDataRegisterRx[offset + 3] );
					printf("%d\n", readDataRegisterRx[offset + 6] );
					printf("%d\n", readDataRegisterRx[offset + 9] );
					printf("%d\n", readDataRegisterRx[offset + 12] );
				}
				return -1;
			}

		}

		data[i].vChannel0 = data[i].rawChannel0 * sDeltaStep; 
		data[i].vChannel1 = data[i].rawChannel1 * sDeltaStep; 
		data[i].vChannel2 = data[i].rawChannel2 * sDeltaStep; 
		data[i].vChannel3 = data[i].rawChannel3 * sDeltaStep;
	}
	return 0;
}
