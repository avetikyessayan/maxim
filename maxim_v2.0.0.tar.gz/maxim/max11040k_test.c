#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>

#include "max11040k.h"


int main(int argc, char **argv)
{
	
	max11040k_debugOn(1);

	if ( 0 != max11040k_init() )
	{
		printf("Unable to initialize max11040k, please try as root\n");
		return -1;
	}
	
	max11040k_enable24Bit(1);
	
	for ( int i = e_DataRate_250_v0; i <= e_DataRate_64000; ++i ) 
	{
		if ( 0 != max11040k_setDataRate((enum dataRates)i))
		{
			printf("Unable to set data rate: %d\n", i);
			return -1;
		}
	}

	max11040k_setDataRate(e_DataRate_250_v0);

	max11040k_debugOn(0);

	while (1)
	{
		struct dataRegister data = { 0 };  
		max11040k_readDataRegister( &data);

		printf("V_Channel_0: %f\tV_Channel_1: %f\tV_Channel_2: %f\tV_Channel_3: %f\n",
				data.vChannel0,
				data.vChannel1,
				data.vChannel2,
				data.vChannel3);
		
		printf("Raw_Channel_0: %.8X\tRaw_Channel_1: %.8X\tRaw_Channel_2: %.8X\tRaw_Channel_3: %.8X\n",
				data.rawChannel0,
				data.rawChannel1,
				data.rawChannel2,
				data.rawChannel3);
		usleep(100000);
		//sleep(1);
	}
	return 0;
}
