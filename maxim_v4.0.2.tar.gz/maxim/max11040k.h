#ifndef _MAX_11040k_
#define _MAX_11040k_

#include <stdint.h>

#define MAX11040_MAX_SUPPORTED_DEVICE_COUNT 4


struct samplingInstantControlRegister
{
	uint8_t data[4];
};

enum dataRates
{
	e_DataRate_250_v0 = 0,
	e_DataRate_250_v1,
	e_DataRate_499,
	e_DataRate_500_v0,
	e_DataRate_500_v1,
	e_DataRate_500_v2,
	e_DataRate_999,
	e_DataRate_1000_v0,
	e_DataRate_1000_v1,
	e_DataRate_1000_v2,
	e_DataRate_1998,
	e_DataRate_2000_v0,
	e_DataRate_2000_v1,
	e_DataRate_2000_v2,
	e_DataRate_3997,
	e_DataRate_4000,
	e_DataRate_4001_v0,
	e_DataRate_4001_v1,
	e_DataRate_7994,
	e_DataRate_8000,
	e_DataRate_8002_v0,
	e_DataRate_8002_v1,
	e_DataRate_15990,
	e_DataRate_16000,
	e_DataRate_16010_v0,
	e_DataRate_16010_v1,
	e_DataRate_31958,
	e_DataRate_32000,
	e_DataRate_32042_v0,
	e_DataRate_32042_v1,
	e_DataRate_63834,
	e_DataRate_64000
};

struct dataRateControlRegister
{
	uint8_t  FSAMPC   : 3;
	uint8_t  reserved : 2;
	uint16_t FSAMPF   : 11;
};

struct configurationRegister
{
	uint8_t SHDN     : 1;
	uint8_t RST      : 1;
	uint8_t EN24BIT  : 1;
	uint8_t XTALEN   : 1;
	uint8_t FAULTDIS : 1;
	uint8_t PDBUF    : 1;
	uint8_t reserved : 2;
};

struct dataRegister 
{
	int32_t rawChannel0;
	int32_t rawChannel1;
	int32_t rawChannel2;
	int32_t rawChannel3;
	double  vChannel0;
	double  vChannel1;
	double  vChannel2;
	double  vChannel3;
	uint8_t deviceAddressTag;
};

int max11040k_init(uint8_t numberOfDevices);
int max11040k_debugOn(uint8_t on);
int max11040k_enable24Bit(uint8_t enable);
int max11040k_setDataRate(enum dataRates rate);
int max11040k_readDataRegister(struct dataRegister *, uint8_t numberOfdevices);

#endif //_MAX_11040k_
