#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>
#include <string.h>
#include <time.h>

#include "max11040k.h"

int max11040_handler(uint8_t debugMode,
		uint8_t en24Bit,
		uint8_t printRaw,
		uint8_t printVoltage,
		uint8_t lowPassFilter,
		uint8_t postToServer,
		int heartz,
		int sampleRate);

void PostToServer( uint8_t debug,
		double ch0,
		double ch1,
		double ch2,
		double ch3);

void printHelpAndAbort()
{
	printf("max11040k [-d] [-p] [-r] [-v] [-f] [-H reading hertz] [-s <sample rate>]\n");

	printf("\t -h : Prints this help\n");
	printf("\t -d : Enable debug mode\n");
	printf("\t -p : Enable high precision mode (24bit mode)\n");
	printf("\t -r : Prints data in raw mode\n");
	printf("\t -v : Prints data in volts\n");
	printf("\t -f : Enable low pass filter\n");
	printf("\t -c : (curl) Post results to the server\n");
	printf("\t -H : Heartz to read from the device, should be greater than 0\n");
	printf("\t -s : Set sample rate of the device\n");
	printf("\t\t Possible values are:\n");
	printf("\t\t 1 -  250   samples per second\n");
	printf("\t\t 2 -  250   samples per second\n");
	printf("\t\t 3 -  499   samples per second\n");
	printf("\t\t 4 -  500   samples per second\n");
	printf("\t\t 5 -  500   samples per second\n");
	printf("\t\t 6 -  500   samples per second\n");
	printf("\t\t 7 -  999   samples per second\n");
	printf("\t\t 8 -  1000  samples per second\n");
	printf("\t\t 9 -  1000  samples per second\n");
	printf("\t\t 10 - 1000  samples per second\n");
	printf("\t\t 11 - 1998  samples per second\n");
	printf("\t\t 12 - 2000  samples per second\n");
	printf("\t\t 13 - 2000  samples per second\n");
	printf("\t\t 14 - 2000  samples per second\n");
	printf("\t\t 15 - 3997  samples per second\n");
	printf("\t\t 16 - 4000  samples per second\n");
	printf("\t\t 17 - 4001  samples per second\n");
	printf("\t\t 18 - 4001  samples per second\n");
	printf("\t\t 19 - 7994  samples per second\n");
	printf("\t\t 20 - 8000  samples per second\n");
	printf("\t\t 21 - 8002  samples per second\n");
	printf("\t\t 22 - 8002  samples per second\n");
	printf("\t\t 23 - 15990 samples per second\n");
	printf("\t\t 24 - 16000 samples per second\n");
	printf("\t\t 25 - 16010 samples per second\n");
	printf("\t\t 26 - 16010 samples per second\n");
	printf("\t\t 27 - 31958 samples per second\n");
	printf("\t\t 28 - 32000 samples per second\n");
	printf("\t\t 29 - 32042 samples per second\n");
	printf("\t\t 30 - 32042 samples per second\n");
	printf("\t\t 31 - 63834 samples per second\n");
	printf("\t\t 32 - 64000 samples per second\n");
	printf("\t Example:\n");
	printf("\t Will display most accurate values in voltage twice per second, without debug information, low pass filter enabled\n");
	printf("\t sudo ./max11040k -s 1 -H 2 -v -p -f\n");
	exit(-1);
}

int main(int argc, char **argv)
{
	
	uint8_t debugMode = 0;
	uint8_t en24Bit = 0;
	uint8_t printRaw = 0;
	uint8_t printVoltage = 0;
	uint8_t lowPassFilter = 0;
	uint8_t postToServer = 0;
	int    sampleRate = -1;
	int    heartz = -1;

	int bflag = 0;
	char *cvalue = NULL;
	int index;
	int c;

	opterr = 0;
	while ((c = getopt (argc, argv, "dprvfcH:s:")) != -1)
		switch (c)
		{
			case 'd':
				debugMode = 1;
				break;
			case 'p':
				en24Bit = 1;
				break;
			case 'r':
				printRaw = 1;
				break;
			case 'v':
				printVoltage = 1;
				break;
			case 'f':
				lowPassFilter = 1;
				break;
			case 'c':
				postToServer = 1;
				break;
			case 's':
				if ( NULL != optarg )
				{
					sampleRate = strtol( optarg, NULL, 10) - 1;
				}
				if (  sampleRate < e_DataRate_250_v0  ||
						sampleRate > e_DataRate_64000 )
				{
					printf("Wrong sample rate specified\n");
					printHelpAndAbort();
				}
				break;
			case 'H':
				if ( NULL != optarg )
				{
					heartz = strtol( optarg, NULL, 10);
				}
				if ( 0 == heartz )
				{
					printf("Wrong heartz specified\n");
					printHelpAndAbort();
				}
				break;
			case 'h':
				printHelpAndAbort();
			default:
				printHelpAndAbort();
		}
	if ( -1 == sampleRate || -1 == heartz)
       	{
		printf("-s and -H should be set\n");
		printHelpAndAbort();
	}

	return max11040_handler( debugMode, en24Bit, printRaw, printVoltage, lowPassFilter, postToServer, heartz, sampleRate);
}

void PostToServer( uint8_t debug,
		double ch0,
		double ch1,
		double ch2,
		double ch3)
{
	// Move to globbal space
	char buff[1024];

	time_t rawtime;   
	time ( &rawtime );
	struct tm *timeinfo = localtime ( &rawtime );

	sprintf( buff, "curl -d  \"{\
\\\"time_stamp\\\": \\\"%02d-%02d-%04d %02d:%02d:%02d\\\",\
\\\"analog_data\\\" :[ \
{\\\"ch0\\\":%f},\
{\\\"ch1\\\":%f},\
{\\\"ch2\\\":%f},\
{\\\"ch3\\\":%f},\
{\\\"ch4\\\":%f},\
{\\\"ch5\\\":%f},\
{\\\"ch6\\\":%f},\
{\\\"ch7\\\":%f}, ],\
\\\"bme280_1_data\\\": [\
{\\\"humidity\\\":34,4189},\
{\\\"pressure\\\":904,018},\
{\\\"temperature\\\":24,61}],\
\\\"bme280_2_data\\\": [\
{\\\"humidity\\\":26.4707},\
{\\\"pressure\\\":904.051},\
{\\\"temperature\\\":27.31}],\
\\\"ads1115_data\\\" :[\
{\\\"ch0\\\":0.574688},\
{\\\"ch1\\\":0.581063},\
{\\\"ch2\\\":3.32869},\
{\\\"ch3\\\":3.32794}]\
}\" -X POST http://seismoinstruments.am/import.php %s", timeinfo->tm_mday,
							timeinfo->tm_mon + 1,
						       	timeinfo->tm_year + 1900,
						      	timeinfo->tm_hour,
						       	timeinfo->tm_min,
						       	timeinfo->tm_sec, 
							ch0,
						       	ch1,
							ch2,
						       	ch3,
						       	0.0L,
						       	0.0L,
						       	0.0L,
						       	0.0L,
						       	(( 1 == debug) ? "" : "> /dev/null 2>&1"));

	if ( 1 == debug )
	{
		printf("Size of string: %u\n%s\n", strlen(buff), buff);
	}

	system(buff);

	if ( 1 == debug )
	{
		printf("\n");
	}
}

int max11040_handler(uint8_t debugMode,
		uint8_t en24Bit,
		uint8_t printRaw,
		uint8_t printVoltage,
		uint8_t lowPassFilter,
		uint8_t postToServer,
		int heartz,
		int sampleRate)
{
	max11040k_debugOn( debugMode);

	if ( 0 != max11040k_init() )
	{
		printf("Unable to initialize max11040k, please try as root\n");
		return -1;
	}

	usleep(100000);
	if ( 0 != max11040k_enable24Bit( en24Bit))
	{
		printf("Unable to set 24 bit mode\n");
		return -1;
	}

	usleep(100000);
	if ( 0 != max11040k_setDataRate( (enum dataRates)sampleRate) )
	{
		printf("Unable to set data rate\n");
		return -1;
	}

	usleep(100000);

	uint32_t uInterval = 1000000 / heartz;
	while (1)
	{
		struct dataRegister data = { 0 };  
		double ch0 = 0;
		double ch1 = 0;
		double ch2 = 0;
		double ch3 = 0;

		long long int rch0 = 0;
		long long int rch1 = 0;
		long long int rch2 = 0;
		long long int rch3 = 0;
		if ( 1 == lowPassFilter )
		{
			uint32_t count = 0;
			struct timeval currentTime = {0};
			struct timeval desiredTime = {0};
			struct timeval deltaTime = {0};
			if ( 1 == heartz )
			{
				deltaTime.tv_sec = 1;
			}
			else
			{
				deltaTime.tv_usec = uInterval;
			}

			if ( 0 == gettimeofday( &currentTime, NULL) )
			{
				timeradd( &currentTime, &deltaTime, &desiredTime);
				do {
					//struct timeval t1, t2, t3;
					//gettimeofday( &t1, NULL); 
					if ( 0 != max11040k_readDataRegister( &data) )
					{
						printf("Faild to read data register\n");
						return -1;
					}

					count++;
					ch0 += data.vChannel0;
					ch1 += data.vChannel1;
					ch2 += data.vChannel2;
					ch3 += data.vChannel3;

					rch0 += data.rawChannel0;
					rch1 += data.rawChannel1;
					rch2 += data.rawChannel2;
					rch3 += data.rawChannel3;

					if ( 0 != gettimeofday( &currentTime, NULL) )
					{
						printf("Unable to get proper time\n");
						break;
					}
					//gettimeofday( &t2, NULL); 
					//timersub( &t2, &t1, &t3);
					//printf("%u, %u\n", t3.tv_sec, t3.tv_usec);
				}
				while( (0 != timercmp(&currentTime, &desiredTime, <)) );
				ch0 /= count; 
				ch1 /= count;
				ch2 /= count;
				ch3 /= count;

				rch0 /= count;
				rch1 /= count;
				rch2 /= count;
				rch3 /= count;

			}
			else
		       	{
				printf("Unable to get proper time\n");
			}
			if ( 1 == debugMode )
			{
				printf("Count: %u\n", count);
			}
			//printf("Count: %u\n", count);

		}
		else
		{
			if ( 0 != max11040k_readDataRegister( &data) )
			{
				printf("Faild to read data register\n");
				return -1;
			}
			ch0 = data.vChannel0;
			ch1 = data.vChannel1;
			ch2 = data.vChannel2;
			ch3 = data.vChannel3;

			rch0 = data.rawChannel0;
			rch1 = data.rawChannel1;
			rch2 = data.rawChannel2;
			rch3 = data.rawChannel3;
		}

		if ( 1 == printRaw )
		{
			printf("Raw_Channel_0: %.16llX\tRaw_Channel_1: %.16llX\tRaw_Channel_2: %.16llX\tRaw_Channel_3: %.16llX\n",
					rch0,
					rch1,
					rch2,
					rch3);
		}

		if ( 1 == printVoltage )
		{
			printf("V_Channel_0: %f\tV_Channel_1: %f\tV_Channel_2: %f\tV_Channel_3: %f\n",
					ch0,
					ch1,
					ch2,
					ch3);
		}
		if ( 1 == postToServer )
		{
			PostToServer( debugMode, ch0, ch1, ch2, ch3);
		}

		if ( 0 == lowPassFilter )
		{
			if ( 1 == heartz )
			{
				sleep(1);
			}
			else
			{
				usleep(1000000 / heartz);
			}
		}
	}
	return 0;
}
